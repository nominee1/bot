<?php
// api/config.php

// Hostinger typically: localhost
define('DB_HOST', 'localhost');
define('DB_NAME', 'u822822525_copytrading');
define('DB_USER', 'u822822525_unchained');
define('DB_PASS', 'bebina1@N');

// CORS origins allowed (adjust to your domains)
define('CORS_ALLOW_ORIGINS', [
    'https://dtraderhub.com',
    'https://www.dtraderhub.com',
    'https://site.denaratool.com',
    'https://www.denaradigitpro.com',
    'https://www.denarapro.com',
    'https://denarapro.com',
    'https://marketing-tawny-ten.vercel.app',
    'https://verify.binaryke.com',
    'https://localhost:8443',
    // add your apps here (e.g., site.denaratool.com) if needed
]);

// ✅ Add this line to expose your encryption key to PHP
// Generate a new one using:  openssl rand -base64 32
putenv('TOKEN_MASTER_KEY=kbdJx5mWnHe0S4g0tPbSW0Mv5wr97RW3uuwxSgXxKp8=');
